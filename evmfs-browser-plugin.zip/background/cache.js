const DB_NAME = 'evmfs-plugin';
const DB_VERSION = 1;
const FILE_STORE = 'files';
const META_STORE = 'meta';
function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(FILE_STORE)) {
                db.createObjectStore(FILE_STORE, { keyPath: 'key' });
            }
            if (!db.objectStoreNames.contains(META_STORE)) {
                db.createObjectStore(META_STORE, { keyPath: 'key' });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}
async function dbPut(store, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(store, 'readwrite');
        tx.objectStore(store).put(value);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
    });
}
async function dbGet(store, key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(store, 'readonly');
        const req = tx.objectStore(store).get(key);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}
/** Cache raw file data by CID */
export async function cacheFile(cid, data, mime) {
    await dbPut(FILE_STORE, {
        key: `file:${cid}`,
        data: data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength),
        mime,
        timestamp: Date.now(),
    });
}
/** Get cached raw file by CID */
export async function getCachedFile(cid) {
    return dbGet(FILE_STORE, `file:${cid}`);
}
/** Cache a site file (from ZIP extraction) */
export async function cacheSiteFile(cid, path, data, mime) {
    await dbPut(FILE_STORE, {
        key: `site:${cid}/${path}`,
        path,
        cid,
        data,
        mime,
        timestamp: Date.now(),
    });
}
/** Get a cached site file */
export async function getCachedSiteFile(cid, path) {
    return dbGet(FILE_STORE, `site:${cid}/${path}`);
}
/** Cache name→CID mapping with TTL */
export async function cacheAlias(name, cid, chainId) {
    await dbPut(META_STORE, {
        key: `alias:${name}`,
        cid,
        chainId,
        timestamp: Date.now(),
    });
}
/** Get cached alias (returns null if expired, TTL = 5 minutes) */
export async function getCachedAlias(name) {
    const entry = await dbGet(META_STORE, `alias:${name}`);
    if (!entry)
        return null;
    if (Date.now() - entry.timestamp > 5 * 60 * 1000)
        return null;
    return { cid: entry.cid, chainId: entry.chainId };
}
